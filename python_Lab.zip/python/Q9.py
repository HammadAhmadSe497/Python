num1=eval(input("Enter num1: "))
num2=eval(input("Enter num2: "))

if num1%num2==0:
    print("\n\nYes it's multiple!")
else:
    print("\n\nNope! It's not multiple of seocnd n!")
