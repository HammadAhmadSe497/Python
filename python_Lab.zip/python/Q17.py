def recFun(num):
    if (num>0):
        print(num)
        recFun(num-1)

#main
num=eval(input("Enter limit: "))
print("\n")
recFun(num)
