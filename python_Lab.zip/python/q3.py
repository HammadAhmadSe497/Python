def function1():
    print(" Hello from a function A")
def function2():
    print(" Hello from a function B")
#Driver code
function1()
function2()