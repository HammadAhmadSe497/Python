def add(a=1, b=2, c=3, d=4, e=5):
    print("Toatal added is: ", a+b+c+d+e)

def multiply(a=1, b=2, c=3, d=4, e=5):
    print("Toatal multiplied is: ", a*b*c*d*e)

#Main
add()
multiply()
